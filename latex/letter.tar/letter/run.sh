#!/bin/bash
cd data
latexmk --interaction=nonstopmode "first.tex"

#!/bin/bash
workdir=/tmp/latex-work-$$
rm -rf $workdir
mkdir $workdir
cp data/* $workdir
cd $workdir
cat head.tex >long.tex
for i in {1..100}; do
	sed "s/qr-1000.png/qr-$i.png/g" onepage.tex >> long.tex
	cp qr-1000.png qr-$i.png
done
cat foot.tex >> long.tex
latexmk -lualatex --interaction=nonstopmode long.tex > mylatex.log
pdfseparate long.pdf out%04d.pdf
cp out0010.pdf /tmp/last.pdf
ls out*.pdf|wc -l >> /tmp/sum.txt

